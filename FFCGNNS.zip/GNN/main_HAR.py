from data_loader_HAR import data_generator  # 导入数据加载函数data_generator

import torch as tr  # 导入PyTorch库并简写为tr
import torch.nn as nn  # 导入神经网络模块并简写为nn
import torch.nn.functional as F  # 导入神经网络函数模块并简写为F
import torch.optim as optim  # 导入优化器模块并简写为optim
import numpy as np  # 导入NumPy库并简写为np
import matplotlib.pyplot as plt  # 导入绘图模块并简写为plt
import time  # 导入时间模块
import math  # 导入数学模块
import os  # 导入操作系统模块

import Model  # 导入自定义的模型类Model

import argparse  # 导入命令行参数解析模块
import random  # 导入随机数模块

class Train():
    def __init__(self, args):  # 初始化方法，接受一个参数args

        # 使用data_generator函数加载数据集，分为训练集、验证集和测试集
        self.train, self.valid, self.test = data_generator('./HAR/', args=args)

        self.args = args  # 将参数args保存为实例属性
        # 初始化模型对象，传入模型参数，并移动模型到GPU（如果可用）
        self.net = Model.FC_STGNN_HAR(args.patch_size,args.conv_out, args.lstmhidden_dim, args.lstmout_dim,args.conv_kernel,args.hidden_dim,args.time_denpen_len, args.num_sensor, args.num_windows,args.moving_window,args.stride, args.decay, args.pool_choice, args.n_class)
        self.net = self.net.cuda() if tr.cuda.is_available() else self.net

        self.loss_function = nn.CrossEntropyLoss()  # 定义交叉熵损失函数
        self.optim = optim.Adam(self.net.parameters())  # 使用Adam优化器优化模型参数

    def Train_batch(self):  # 训练一个批次数据的方法
        self.net.train()  # 设置模型为训练模式
        loss_ = 0  # 初始化损失为0
        for data, label in self.train:  # 遍历训练集数据
            data = data.cuda() if tr.cuda.is_available() else data  # 将数据移动到GPU（如果可用）
            label = label.cuda() if tr.cuda.is_available() else label  # 将标签移动到GPU（如果可用）
            self.optim.zero_grad()  # 梯度清零
            prediction = self.net(data)  # 模型预测
            loss = self.loss_function(prediction, label)  # 计算损失
            loss.backward()  # 反向传播
            self.optim.step()  # 更新模型参数
            loss_ = loss_ + loss.item()  # 累加损失
        return loss_  # 返回累计损失

    def Train_model(self):  # 训练整个模型的方法
        epoch = self.args.epoch  # 获取训练轮数
        cross_accu = 0  # 初始化交叉验证准确率为0
        test_accu_ = []  # 初始化测试准确率列表
        prediction_ = []  # 初始化预测结果列表
        real_ = []  # 初始化真实标签列表

        for i in range(epoch):  # 遍历每个epoch
            time0 = time.time()  # 记录当前时间
            loss = self.Train_batch()  # 训练一个批次数据
            if i % self.args.show_interval == 0:  # 每隔一定间隔显示信息
                accu_val = self.Cross_validation()  # 执行交叉验证

                if accu_val > cross_accu:  # 如果交叉验证准确率提高
                    cross_accu = accu_val  # 更新最佳交叉验证准确率
                    test_accu, prediction, real = self.Prediction()  # 进行测试集预测

                    # 打印测试准确率和epoch信息
                    print('In the {}th epoch, TESTING accuracy is {}%'.format(i, np.round(test_accu, 3)))
                    test_accu_.append(test_accu)  # 记录测试准确率
                    prediction_.append(prediction)  # 记录预测结果
                    real_.append(real)  # 记录真实标签

        np.save('./experiment/{}.npy'.format(self.args.save_name),[test_accu_, prediction_, real_])  # 保存实验结果

    def cuda_(self, x):  # 将数据移动到GPU的方法
        x = tr.Tensor(np.array(x))  # 转换为PyTorch张量

        if tr.cuda.is_available():  # 如果GPU可用
            return x.cuda()  # 移动到GPU
        else:
            return x  # 返回原始张量

    def Cross_validation(self):  # 执行交叉验证的方法
        self.net.eval()  # 设置模型为评估模式
        prediction_ = []  # 初始化预测结果列表
        real_ = []  # 初始化真实标签列表
        for data, label in self.valid:  # 遍历验证集数据
            data = data.cuda() if tr.cuda.is_available() else data  # 将数据移动到GPU（如果可用）
            real_.append(label)  # 添加真实标签
            prediction = self.net(data)  # 模型预测
            prediction_.append(prediction.detach().cpu())  # 添加预测结果
        prediction_ = tr.cat(prediction_,0)  # 将预测结果拼接为一个张量
        real_ = tr.cat(real_,0)  # 将真实标签拼接为一个张量

        prediction_ = tr.argmax(prediction_,-1)  # 获取最大值的索引作为预测类别

        accu = self.accu_(prediction_, real_)  # 计算准确率
        return accu  # 返回准确率

    def Prediction(self):  # 预测测试集结果的方法
        self.net.eval()  # 设置模型为评估模式
        prediction_ = []  # 初始化预测结果列表
        real_ = []  # 初始化真实标签列表
        for data, label in self.test:  # 遍历测试集数据
            data = data.cuda() if tr.cuda.is_available() else data  # 将数据移动到GPU（如果可用）
            real_.append(label)  # 添加真实标签
            prediction = self.net(data)  # 模型预测
            prediction_.append(prediction.detach().cpu())  # 添加预测结果
        prediction_ = tr.cat(prediction_, 0)  # 将预测结果拼接为一个张量
        real_ = tr.cat(real_, 0)  # 将真实标签拼接为一个张量

        prediction_ = tr.argmax(prediction_, -1)  # 获取最大值的索引作为预测类别
        accu = self.accu_(prediction_, real_)  # 计算准确率
        return accu, prediction_, real_  # 返回准确率、预测结果和真实标签

    def accu_(self, predicted, real):  # 计算准确率的方法
        num = predicted.size(0)  # 获取样本总数
        real_num = 0  # 初始化正确预测样本数为0
        for i in range(num):  # 遍历每个样本
            if predicted[i] == real[i]:  # 如果预测结果与真实标签相同
                real_num += 1  # 正确预测样本数加1
        return 100 * real_num / num  # 返回准确率

if __name__ == '__main__':  # 如果作为主程序运行
    from args import args  # 导入参数类args

    args = args()  # 创建参数对象

    # 配置参数
    def args_config_HAR(args):
        args.epoch = 41  # 训练轮数
        args.k = 1  # 参数k
        args.window_sample = 128  # 窗口采样数

        args.decay = 0.7  # 学习率衰减
        args.pool_choice = 'mean'  # 池化方式
        args.moving_window = [2, 2]  # 移动窗口
        args.stride = [1, 2]  # 步长
        args.lr = 1e-3  # 学习率
        args.batch_size = 100  # 批大小

        args.conv_kernel = 6  # 卷积核大小
        args.patch_size = 64  # 补丁大小
        args.time_denpen_len = int(args.window_sample / args.patch_size)  # 时间依赖长度
        args.conv_out = 10  # 卷积输出通道数
        args.num_windows = 2  # 窗口数量

        args.conv_time_CNN = 6  # 时间卷积CNN

        args.lstmout_dim = 18  # LSTM输出维度
        args.hidden_dim = 16  # 隐藏层维度
        args.lstmhidden_dim = 48  # LSTM隐藏层维度

        args.num_sensor = 9  # 传感器数量         ########################################################################
        args.n_class = 6  # 类别数量
        return args  # 返回配置后的参数对象

    args = args_config_HAR(args)  # 配置参数

    train = Train(args)  # 创建训练对象
    train.Train_model()  # 训练模型
